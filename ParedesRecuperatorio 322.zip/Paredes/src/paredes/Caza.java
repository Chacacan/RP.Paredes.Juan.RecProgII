
package paredes;

import java.util.Objects;


public class Caza {
    private String nombre;
    private int hangar;
    private TipoDespliegue tipo;

    public Caza(String nombre, int hangar, TipoDespliegue tipo) {
        this.nombre = nombre;
        this.hangar = hangar;
        this.tipo = tipo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getHangar() {
        return hangar;
    }

    public void setHangar(int hangar) {
        this.hangar = hangar;
    }

    public TipoDespliegue getTipo() {
        return tipo;
    }

    public void setTipo(TipoDespliegue tipo) {
        this.tipo = tipo;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.nombre);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof Caza c)) {
            return false;
        }
        
        return this.tipo == c.tipo;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Caza{");
        sb.append("nombre=").append(nombre);
        sb.append(", hangar=").append(hangar);
        sb.append(", tipo=").append(tipo);
        sb.append('}');
        return sb.toString();
    }
    
    
    
}
