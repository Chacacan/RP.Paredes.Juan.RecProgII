
package paredes;


public enum TipoInterferencia {
    RADAR,
    COMUNICACIONES
}
