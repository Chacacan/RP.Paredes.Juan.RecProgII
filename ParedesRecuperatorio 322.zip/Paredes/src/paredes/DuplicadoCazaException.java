
package paredes;


public class DuplicadoCazaException extends Exception{

    public DuplicadoCazaException(String message) {
        super(message);
    }
    
}
