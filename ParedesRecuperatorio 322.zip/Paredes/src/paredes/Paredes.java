
package paredes;


public class Paredes {


    public static void main(String[] args) {
        ThunderStrike aviones = new ThunderStrike();
        
        try {
            CazaLigero c1 = new CazaLigero("Falcon-21", 3, TipoDespliegue.AIRE, 0);
            CazaLigero c2 = new CazaLigero("Falcon-21", 3, TipoDespliegue.AIRE, 0);
            CazaElectronico e1 = new CazaElectronico("Falcon-22", 2, TipoDespliegue.AIRE, TipoInterferencia.COMUNICACIONES);
            aviones.agregarCaza(c1);
            aviones.agregarCaza(c2);
            aviones.agregarCaza(e1);
        } catch (DuplicadoCazaException mensaje) {
            System.out.println("Avion duplicado " + mensaje.getMessage());
        }
        
        aviones.mostrarCazas();
        
        aviones.realizarAccionEspecial();
        System.out.println("----------------Despliegue por aire--------------");
        aviones.filtrarPorTipoDespliegue(TipoDespliegue.AIRE);
        
        aviones.eliminarCazasPorTipo("Caza Electronico");
    }
    
}
