
package paredes;


public enum TipoDespliegue {
    AIRE,
    TIERRA
}
