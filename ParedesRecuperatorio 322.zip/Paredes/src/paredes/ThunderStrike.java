
package paredes;

import java.util.ArrayList;
import java.util.List;


public class ThunderStrike {
    List<Caza> aviones;

    public ThunderStrike() {
        aviones = new ArrayList<>();
    }
    
    public void agregarCaza(Caza caza) throws DuplicadoCazaException{
        if(aviones.contains(caza)){
            throw new DuplicadoCazaException("El Caza " + caza.getNombre()+" ya existe en el hangar "+ caza.getHangar());
        }
        aviones.add(caza);
    }
    
    private boolean validarAviones(){
        return aviones.isEmpty();
    }
    
    public void mostrarCazas(){
        if(validarAviones()){
            System.out.println("No hay aviones registrados");
        }else{
            for (Caza avione : aviones) {
                System.out.println(avione.toString());
            }
        }
            
    }
    
    public void despegar(){
        List<Caza> noDespegados= new ArrayList<>();
        if(!validarAviones()){
            for (Caza avione : aviones) {
                if(avione instanceof Despegue){
                   ((Despegue) avione).despegar();
                }else{
                    noDespegados.add(avione);
                }
            }
        }
        if(!noDespegados.isEmpty()){
            System.out.println("Los siguiente aviones no pueden despegar::::::");
            for (Caza noDespegado : noDespegados) {
                System.out.println(noDespegado.toString());
            }
        }
            
    }
    public void realizarAccionEspecial(){
        if(!validarAviones()){
            for (Caza avione : aviones) {
                if(avione instanceof CazaLigero){
                    ((CazaLigero) avione).maniobraEvacion();
                }else if (avione instanceof CazaPesado){
                    ((CazaPesado) avione).ataqueDirigido();
                }else if(avione instanceof CazaElectronico){
                    ((CazaElectronico) avione).bloquearSistemasEnemigos();
                }else{
                    System.out.println("El avion: " + avione.getNombre()+ " No puede realizar ninguna accion");
                }
            }
        }else{
            System.out.println("No hay aviones registrados");
        }
            

    }
    
    public List<Caza> filtrarPorTipoDespliegue(TipoDespliegue tipo){
        List<Caza> nuevaLista = new ArrayList<>();
        if(!validarAviones()){
            for (Caza caza : aviones) {
                if(caza.getTipo() == tipo){
                    System.out.println(caza.toString());
                    nuevaLista.add(caza);
                }
            }
        }
        return nuevaLista;
    }

    public void eliminarCazasPorTipo(String tipoCaza) {
    List<Caza> restantes = new ArrayList<>();
    int eliminados = 0;

    for (Caza caza : aviones) {
        boolean esElTipo = 
            (tipoCaza.equalsIgnoreCase("CazaLigero") && caza instanceof CazaLigero) ||
            (tipoCaza.equalsIgnoreCase("CazaPesado") && caza instanceof CazaPesado) ||
            (tipoCaza.equalsIgnoreCase("CazaElectrónico") && caza instanceof CazaElectronico);

        if (esElTipo) {
            eliminados++; 
        } else {
            restantes.add(caza);
        }
    }

    aviones = restantes; 

    System.out.println("Cazas eliminados del tipo " + tipoCaza + ": " + eliminados);
}

    
}
