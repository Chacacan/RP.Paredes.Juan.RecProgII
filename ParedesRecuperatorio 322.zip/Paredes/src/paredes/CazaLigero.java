
package paredes;


public class CazaLigero extends Caza implements Reconocimiento,Despegue{
    private double velocidadMaxima;

    public CazaLigero( String nombre, int hangar, TipoDespliegue tipo,double velocidadMaxima) {
        super(nombre, hangar, tipo);
        this.velocidadMaxima = velocidadMaxima;
    }

    public double getVelocidadMaxima() {
        return velocidadMaxima;
    }
    
    public void maniobraEvacion() {
        System.out.println("El avion " + getNombre()+ " realiza evacion");
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("\n");
        sb.append("CazaLigero{");
        sb.append("velocidadMaxima=").append(velocidadMaxima);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public void realizarReconocimiento() {
        System.out.println("puede realizar reconocimiento");
    }

    @Override
    public void despegar() {
        System.out.println("el avion despega");
    }

    
    
}
