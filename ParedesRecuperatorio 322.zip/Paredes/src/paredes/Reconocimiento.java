
package paredes;


public interface Reconocimiento {
    void realizarReconocimiento();
}
