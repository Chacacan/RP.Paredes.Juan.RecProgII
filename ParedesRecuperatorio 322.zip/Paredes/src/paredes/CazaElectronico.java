
package paredes;


public class CazaElectronico extends Caza implements Reconocimiento{
    private TipoInterferencia tipoInterferencia;

    public CazaElectronico(String nombre, int hangar, TipoDespliegue tipo, TipoInterferencia tipoInterferencia) {
        super(nombre, hangar, tipo);
        this.tipoInterferencia = tipoInterferencia;
    }
    
    
    public void bloquearSistemasEnemigos(){
        System.out.println("El avion " + getNombre()+ " realiza bloqueo");
    }

    public TipoInterferencia getTipoInterferencia() {
        return tipoInterferencia;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("CazaElectronico{");
        sb.append("tipoInterferencia=").append(tipoInterferencia);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public void realizarReconocimiento() {
        System.out.println("puede realizar reconocimiento");
    }
    

    
}
