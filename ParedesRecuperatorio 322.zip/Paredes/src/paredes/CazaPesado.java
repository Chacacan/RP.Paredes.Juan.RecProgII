
package paredes;


public class CazaPesado extends Caza implements Despegue{
    private int capacidadMaximaArmamento;

    public CazaPesado(String nombre, int hangar, TipoDespliegue tipo,int capacidadMaximaArmamento) {
        super(nombre, hangar, tipo);
        this.capacidadMaximaArmamento = capacidadMaximaArmamento;
    }

    public int getCapacidadMaximaArmamento() {
        return capacidadMaximaArmamento;
    }
    
    
    
    public void ataqueDirigido(){
        System.out.println("El avion " + getNombre()+ " realiza Átaque");
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("CazaPesado{");
        sb.append("capacidadMaximaArmamento=").append(capacidadMaximaArmamento);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public void despegar() {
System.out.println("el avion despega");
    }
    
    
    
}
