package paredes;


public interface Despegue {
    void despegar();
}
