
package rp.juan.paredes.pkg322n;


public interface PracticaEnPareja {
    void practicaEnPareja();
}
