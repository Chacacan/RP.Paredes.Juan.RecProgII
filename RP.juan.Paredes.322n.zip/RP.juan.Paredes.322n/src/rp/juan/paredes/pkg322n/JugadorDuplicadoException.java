
package rp.juan.paredes.pkg322n;


public class JugadorDuplicadoException extends Exception {
    public JugadorDuplicadoException(String mensaje){
        super(mensaje);
    }
}
