
package rp.juan.paredes.pkg322n;


public enum Superficie {
   POLVO, 
   CESPED,
   CEMENTO
}
