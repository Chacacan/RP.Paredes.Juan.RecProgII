
package rp.juan.paredes.pkg322n;


public interface Sacador {
    void sacar();
}
